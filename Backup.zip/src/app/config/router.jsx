//here we are going to export instructions for our router so the router knows what components are active based on what our path is

//as always 
var React = require('react');

//because this is indeed the router and we... npm install --save react-router ...earlier when in App.js
var Router = require('react-router');
var DefaultRoute = Router.DefaultRoute;
var Route = Router.Route;

//the components we have built
var Main = require('../components/main.jsx');
var Home = require('../components/Home.jsx');
var Listening = require('../components/listening.jsx');
var Modal = require('../components/modal.jsx');
var Footer = require('../components/footer.jsx');
var Todo = require('../components/Header.jsx');

// var Navigation = require('../components/navigation');
// var Reddit = require('../components/reddit.jsx');

console.log(Route);

module.exports = (
	          //when we hit /, route will serve up main
	<Route name="app" path="/" handler={Main}>
	    <Route name="foot" path="/" handler={Footer} />
		<Route name="listening" path="/listening" handler={Listening} />
		<Route name="modal" path="/modal" handler={Modal} />
		<Route name="todo" path="/todo" handler={Todo} />
		<Route name="home" path="/:station" handler={Home} />
		<Route name="default" path="/*" handler={Home} />
	</Route>
);

		//if none of them match, we have a default
		// <DefaultRoute handler={Main} />

		//we are going to have multiple routes here
		//<Route name="profile" path="profile/:username" handler={Profile} />