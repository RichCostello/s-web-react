var React = require('react');

//nifty, they include a router..  npm install --save react-router
var Router = require('react-router');

var routes = require('./config/router.jsx');

var injectTapEventPlugin = require("react-tap-event-plugin");

var Main = require('./components/main.jsx');

    //Needed for React Developer Tools
    window.React = React;

    //Needed for onTouchTap
    //Can go away when react 1.0 release
    //Check this repo:
    //https://github.com/zilverline/react-tap-event-plugin
    injectTapEventPlugin();


    //**//**//**/**// This is going away in favor of a router //**//**//**//**//
    // Render the main app react component into the document body.
    // For more details see: https://facebook.github.io/react/docs/top-level-api.html#react.render
    // React.render(<Main />, document.body);
    //**//**//**/**//**//**//**//**/**//**//**//**//**/**//**//**//**//**/**//**

//when the path changes react-router will dectect it and pass us the component that we want to render instead of just rendering main
//then inside router we can determine what Root is going to be

Router.run(routes, function(Root){
    React.render(<Root />, document.getElementById('app'));
});

