var React = require('react');
var SkyLight = require('react-skylight');
var RefreshMap  = require('./map.jsx');
 
var dialogStyles = {
    width: '520px',
    height: '560px',
    position: 'fixed',
    top: '50%',
    left: '50%',
    marginTop: '-280px',
    marginLeft: '-260px',
    backgroundColor: '#fff',
    borderRadius: '2px',
    zIndex: 10000,
    padding: '10px',
    boxShadow: '0 0 4px rgba(0,0,0,.14),0 4px 8px rgba(0,0,0,.28)'
}
var overlayStyles = {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    zIndex: 9999,
    backgroundColor: 'rgba(0,0,0,0.5)'
}

var Modal = React.createClass({
  showDialogWithCallBacks: function(){
    this.refs.dialogWithCallBacks.show();
  },
  showSimpleDialog: function(){
    this.refs.simpleDialog.show();
  },
  render:function(){
    return (
      <div>
        <p>
          <button onClick={this.showSimpleDialog}>Modal without callbacks</button>
        </p>
        <SkyLight ref="dialogWithCallBacks" overlayStyles={overlayStyles} dialogStyles={dialogStyles} title={this.props.title}
                  beforeOpen={this._executeBeforeFirstModalOpen}
                  afterOpen={this._executeAfterFirstModalOpen}
                  beforeClose={this._executeBeforeFirstModalClose}
                  afterClose={this._executeAfterFirstModalClose}>I have callbacks!</SkyLight>
        <SkyLight ref="simpleDialog" title="">
          <RefreshMap/>
        </SkyLight>
      </div>
    )
  },
  _executeBeforeFirstModalOpen: function(){
    alert('Executed before open');
  },
  _executeAfterFirstModalOpen: function(){
    alert('Executed after open');
  },
  _executeBeforeFirstModalClose: function(){
    alert('Executed before close');
  },
  _executeAfterFirstModalClose: function(){
    alert('Executed after close');
  }
});

module.exports = Modal;