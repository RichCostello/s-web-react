var React = require('react');




var Listening = React.createClass({

	render: function(){
		return(
			<h2 className="listening">
				Listening
			</h2>
		)
	}
});

module.exports = Listening;