var React = require('react');
var Bootstrap = require('react-bootstrap');




var MainSection = require('./MainSection.jsx');
var Navigation = require('../components/navigation.jsx');


//RouteHandler is going to be swapped depending on our path
//See app/config/routes.js
var RouteHandler = require('react-router').RouteHandler;



var Main = React.createClass({
    render: function () {
        return (
            <div>
               
               

                <Navigation />
                
                <RouteHandler />
                


            </div>
        );
    }

});

module.exports = Main;