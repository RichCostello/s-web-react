var React = require('react');

var Router = require('react-router');


var Home = React.createClass({
	mixins: [Router.State],
	render: function(){
	var station = this.getParams().station;

	if(station == 'josh'){
		return(
			<h2 className="hometext">
				{station} HOME TEXT
			</h2>
		)
	}else{
		return(
			<h2 className="hometext">
				404 page not found
			</h2>
		)
	}

	}
});

module.exports = Home;