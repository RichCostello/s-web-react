var React = require('react');
var Bootstrap = require('react-bootstrap');

var counter = 0;

var Posts = React.createClass({

    getInitialState: function() {
        return {data: []};
    },
    loadItemsFromServer: function() {
        counter++;        
        this.forceUpdate();
    },
    componentDidMount: function() {
        this.loadItemsFromServer();
        setInterval(this.loadItemsFromServer, this.props.pollInterval);
    },
    render: function() {
        return (
            <div className="footer">
                <a href="#">{counter}</a>
            </div>
        );
    }
});

module.exports = Posts;
