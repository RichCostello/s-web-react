var React = require('react');
var Bootstrap = require('react-bootstrap');

var counter = 0;

var Footer = React.createClass({

    render: function() {
        return (
            <footer className="footer">
              <div className="container">
                    <ul>
                        <li><a href="">About</a></li>
                        <li><a href="">Blog</a></li>
                        <li><a href="">Terms</a></li>
                        <li><a href="">Privacy</a></li>
                    </ul>
              </div>
            </footer>
        );
    }
});

module.exports = Footer;
